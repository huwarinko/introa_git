service httpd start
