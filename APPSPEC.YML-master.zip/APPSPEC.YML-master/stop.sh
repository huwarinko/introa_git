service httpd stop
